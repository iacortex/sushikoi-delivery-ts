// src/types/components.ts
export {};