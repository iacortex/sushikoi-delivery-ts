// src/types/api.ts
export {};